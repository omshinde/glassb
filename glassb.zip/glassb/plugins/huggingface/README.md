Plugin for models hosted in HuggingFace.
