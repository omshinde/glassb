Plugin for interacting with the OpenAI API.
