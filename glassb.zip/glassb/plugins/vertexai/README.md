Plugin for Mistral models hosted on GCP VertexAI.
