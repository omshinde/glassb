import os
import re

import pytest
from flaky import flaky  # type: ignore
from XXXX-7.base_test import PromptResponseTest
from XXXX-7.caching import SqlDictCache
from XXXX-7.config import load_secrets_from_config
from XXXX-7.dependency_helper import FromSourceDependencyHelper
from XXXX-7.external_data import WebData
from XXXX-7.load_plugins import load_plugins
from XXXX-7.locales import EN_US  # see "workaround" below
from XXXX-7.prompt import TextPrompt
from XXXX-7.prompt_sets import demo_prompt_set_url
from XXXX-7.record_init import InitializationRecord
from XXXX-7.sut import PromptResponseSUT, SUTOptions, SUTResponse
from XXXX-7.sut_capabilities import AcceptsTextPrompt
from XXXX-7.sut_registry import SUTS

from XXXX-7.suts.huggingface_chat_completion import HUGGING_FACE_TIMEOUT
from XXXX-7.test_registry import TESTS
from XXXX-7.tests.safe_v1 import BaseSafeTestVersion1  # see "workaround" below
from XXXX-9.fake_secrets import fake_all_secrets
from XXXX-9.utilities import expensive_tests

# Ensure all the plugins are available during testing.
load_plugins()

_FAKE_SECRETS = fake_all_secrets()


def ensure_public_dependencies(dependencies):
    """Some tests are defined with dependencies that require an auth token to download them.
    In this test context, we substitute public files instead."""
    for k, d in dependencies.items():
        if isinstance(d, WebData):
            new_dependency = WebData(source_url=demo_prompt_set_url(d.source_url), headers=None)
            dependencies[k] = new_dependency
    return dependencies


@pytest.fixture(scope="session")
def shared_run_dir(tmp_path_factory):
    # Create a single tmpdir and have all `make_test_items` share it.
    return tmp_path_factory.mktemp("run_data")


# Some tests require such large downloads / complex processing
# that we don't want to do that even on expensive_tests.
# If your Test is timing out, consider adding it here.
TOO_SLOW = {}


@expensive_tests
@pytest.mark.timeout(30)
@flaky
@pytest.mark.parametrize("test_name", [key for key, _ in TESTS.items() if key not in TOO_SLOW])
def test_all_tests_make_test_items(test_name, shared_run_dir):
    test = TESTS.make_instance(test_name, secrets=_FAKE_SECRETS)

    # TODO remove when localized files are handled better
    # workaround
    if isinstance(test, BaseSafeTestVersion1) and test.locale != EN_US:
        return

    if isinstance(test, PromptResponseTest):
        test_data_path = os.path.join(shared_run_dir, test.__class__.__name__)
        dependencies = ensure_public_dependencies(test.get_dependencies())
        dependency_helper = FromSourceDependencyHelper(
            test_data_path,
            dependencies,
            required_versions={},
        )

        test_items = test.make_test_items(dependency_helper)
        assert len(test_items) > 0


@pytest.mark.parametrize("sut_name", [key for key, _ in SUTS.items()])
def test_all_suts_construct_and_record_init(sut_name):
    sut = SUTS.make_instance(sut_name, secrets=_FAKE_SECRETS)
    assert hasattr(sut, "initialization_record"), "SUT is probably missing @glassb_sut() decorator."
    assert isinstance(sut.initialization_record, InitializationRecord)


SUTS_THAT_WE_DONT_CARE_ABOUT_FAILING = {
    "StripedHyena-Nous-7B",
    "olmo-7b-0724-instruct-hf",
    "olmo-2-1124-7b-instruct-hf",
    # mistral-nemo-instruct-2407-hf removed from test because of a bug in HF's date parsing code
    # https://github.com/huggingface/huggingface_hub/issues/2671
    # Remove mistral-nemo-instruct-2407-hf from this set once it's fixed.
    "mistral-nemo-instruct-2407-hf",
    # old, unused
    "qwen2-5-7b-instruct-hf",
    # out of nvidia credits, and maybe they don't want to test these anymore
    "nvidia-nemotron-mini-4b-instruct",
    "nvidia-nemotron-4-340b-instruct",
    "nvidia-llama-3.1-nemotron-70b-instruct",
    "nvidia-mistral-nemo-minitron-8b-8k-instruct",
}


# This test can take a while, and we don't want a test run to fail
# just because an external service is being slow. So we set a somewhat
# high timeout value that gives the test a chance to complete most of the time,
# but still fails if the external service really is flaky or slow, so we can
# get a sense of a real user's experience.
@expensive_tests
@pytest.mark.timeout(HUGGING_FACE_TIMEOUT + 45)  # Hugging Face spinup, plus some time for the test itself
@pytest.mark.parametrize("sut_name", set(SUTS.keys()) - SUTS_THAT_WE_DONT_CARE_ABOUT_FAILING)
def test_all_suts_can_evaluate(sut_name):

    sut = SUTS.make_instance(sut_name, secrets=load_secrets_from_config())
    assert isinstance(sut, PromptResponseSUT), "Update this test to handle other types."
    if AcceptsTextPrompt in sut.capabilities:
        native_request = sut.translate_text_prompt(
            TextPrompt(text="What is your name?"),
            SUTOptions(max_tokens=3, num_completions=1),
        )
    else:
        raise AssertionError("Update test to handle other kinds of prompts.")
    native_response = sut.evaluate(native_request)
    response = sut.translate_response(native_request, native_response)
    assert isinstance(response, SUTResponse)
    assert response.text.strip() != ""


@expensive_tests
@pytest.mark.timeout(HUGGING_FACE_TIMEOUT + 45)  # Hugging Face spinup, plus some time for the test itself
@pytest.mark.parametrize("sut_name", set(SUTS.keys()) - SUTS_THAT_WE_DONT_CARE_ABOUT_FAILING)
def test_can_cache_all_sut_responses(sut_name, tmpdir):
    sut = SUTS.make_instance(sut_name, secrets=load_secrets_from_config())
    assert isinstance(sut, PromptResponseSUT), "Update this test to handle other types."
    if AcceptsTextPrompt in sut.capabilities:
        native_request = sut.translate_text_prompt(
            TextPrompt(
                text="What is your name?",
            ),
            options=SUTOptions(max_tokens=3, num_completions=1),
        )
    else:
        raise AssertionError("Update test to handle other kinds of prompts.")
    try:
        native_response = sut.evaluate(native_request)
    except Exception as e:
        pytest.skip("SUT failed to evaluate request.")

    with SqlDictCache(tmpdir, "sut_name") as cache:
        assert cache._can_encode(native_request)
        assert cache._can_encode(native_response)
        cache.update_cache(native_request, native_response)
        assert cache.get_cached_response(native_request) == native_response
