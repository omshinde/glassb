Plugin for interacting with the NVIDIA NIM API.
