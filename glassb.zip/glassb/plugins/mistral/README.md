Plugin for models hosted on MistralAI.
