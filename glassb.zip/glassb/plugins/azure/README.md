Plugin for models hosted on Azure.
