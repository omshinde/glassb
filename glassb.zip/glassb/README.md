
# glassb_bench

Run safety benchmarks against AI models and view detailed reports showing how well they performed.

## Badges

[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
![Python Version from PEP 621 TOML](https://img.shields.io/python/required-version-toml?tomlFilePath=https%3A%2F%2Fraw.githubusercontent.com%2Fyyyy%2Fglassb_bench%2Fmain%2Fpyproject.toml)
![GitHub Actions Workflow Status](XXXX-3)

## Background

This is a [XXXX-3 project](XXXX-3),
part of the [Global AI Safety Working
Group](XXXX-3).
The project is at an early stage. You can see sample benchmarks
[here](XXXX-1) and our xx white paper
[here](https://xxxx.org/abs/xxxx.xxxxx).

This project now contains both XXXX-7 andXXXX-6. XXXX-7 does
most of the work of running Tests against SUTs (systems under test,
that is machine learning models and related tech) and then using
annotators to measure each response. glassb_bench aggregates those measures,
relates them to specific Hazards, rolls those Hazards up into Benchmarks, and
produces reports. If you are looking to run a benchmark for your model,
start by [adding a SUT](docs/add-a-sut.md) that works with XXXX-7.

## Requirements

The current public practice benchmark uses LlamaGuard to
evaluate the safety of responses. For now you will need a
[Together AI](https://www.together.ai/) account to use it. For 1.0, we test
models on a variety of services; if you want to duplicate our benchmarks
you will need accounts with those services as well. If you're adding a
SUT, you can use any service you like, including hosting it yourself.

Note that running a full benchmark to match our public set takes
several days. Depending on response time, running your own SUT may be
faster. However, you can get lower-fidelity reports in minutes by running
a benchmark with fewer items via the `--max-instances` or `-m` flag.

## Installation

Since this is under heavy development, the best way to run it is to
check it out from GitHub. However, you can also installXXXX-6 as
a CLI tool or library to use in your own projects.

### InstallXXXX-6 with [Poetry](https://python-poetry.org/) for local development.

1. Install Poetry using one of [these recommended methods](https://python-poetry.org/docs/#installation).  All of these methods require a recent version of python3 to be installed and available on your shell path.  For example:
```shell
pipx install poetry
```

2. Clone this repository.
```shell
git clone XXXX-3
```

3. Make sure that you have no python virtual environments activated.  They will interfere with the poetry setup.

4. InstallXXXX-6 and dependencies.
```shell
cdXXXX-6
poetry install
```

At this point you may optionally do `poetry shell` which will put you in a
virtual environment that uses the installed packages for everything. If
you do that, you don't have to explicitly say `poetry run` in the
commands below.

### InstallXXXX-6 from PyPI

1. InstallXXXX-6 into your local environment or project the way you normally would. For example:
```shell
pip installXXXX-6
```

## Running Tests

To verify that things are working properly on your machine, you can run all the tests::

```shell
poetry run pytest tests
```

## Trying It Out

We encourage interested parties to try it out and give us feedback. For
now, glassb_bench is mainly focused on us running our own benchmarks,
but over time we would like others to be able both test their own models
and to create their own tests and benchmarks.

### Running Your First Benchmark

Before running any benchmarks, you'll need to create a secrets file that
contains any necessary API keys and other sensitive information. Create a
file at `config/secrets.toml` (in the current working directory if you've
installedXXXX-6 from PyPi). You can use the following as a template.

```toml
[together]
api_key = "<your key here>"
```

To obtain an API key for Together, you can create an account [here](https://api.together.xyz/).

With your keys in place, you are now ready to run your first benchmark!
Note: Omit `poetry run` in all example commands going forward if you've installedXXXX-6 from PyPi.

```shell
poetry runXXXX-6 benchmark -m 10
```

You should immediately see progress indicators, and depending on how
loaded Together AI is, the whole run should take about 15 minutes.

> [!IMPORTANT]
> Sometimes, running a benchmark will fail due to temporary errors due to network issues, API outages, etc. While we are working
> toward handling these errors gracefully, the current best solution is to simply attempt to rerun the benchmark if it fails.

### Viewing the Scores

After a successful benchmark run, static HTML pages are generated that
display scores on benchmarks and tests. These can be viewed by opening
`web/index.html` in a web browser. E.g., `firefox web/index.html`.

Note that the HTML thatXXXX-6 produces is an older version than is available
on [the website](XXXX-1). Over time we'll simplify the
directXXXX-6 output to be more straightforward and more directly useful to
people independently runningXXXX-6.

### Using the journal

As `glassb_bench` runs, it logs each important event to the journal. That includes
every step of prompt processing. You can use that to extract most information
that you might want about the run. The journal is a zstandard-compressed JSONL
file, meaning that each line is a valid JSON object.

There are many tools that can work with those files. In the example below, we
use [jq](https://jqlang.github.io/jq/, a JSON swiss army knife. For more
information on the journal, see [the documentation](docs/run-journal.md).

To dump the raw scores, you could do something like this

```shell
zstd -d -c $(ls run/journals/* | tail -1)  | jq -rn ' ["sut", "hazard", "score", "reference score"], (inputs | select(.message=="hazard scored") | [.sut, .hazard, .score, .reference]) | @csv'
```

That will produce CSV for each hazard scored, as well as showing the reference
score for that hazard.

Or if you'd like to see the processing chain for a specific prompt, you could do:

```shell
zstd -d -c $(ls run/journals/* | tail -1)  | jq -r 'select(.prompt_id=="airr_practice_1_0_41321")'
```

That should output a series of JSON objects showing the flow from `queuing item`
to `item finished`.

**CAUTION**: Please note that many of the prompts may be uncomfortable or
harmful to view, especially to people with a history of trauma related to
one of the hazards that we test for. Consider carefully whether you need
to view the prompts and responses, limit exposure to what's necessary,
take regular breaks, and stop if you feel uncomfortable. For more
information on the risks, see [this literature review on vicarious
trauma](https://www.zevohealth.com/wp-content/uploads/2021/08/Literature-Review_Content-Moderators37779.pdf).

### Managing the Cache

To speed up runs, glassb_bench caches calls to both SUTs and
annotators. That's normally what a benchmark-runner wants. But if you
have changed your SUT in a way thatXXXX-6 can't detect, like by
deploying a new version of your model to the same endpoint, you may
have to manually delete the cache. Look in `run/suts` for an `sqlite`
file that matches the name of your SUT and either delete it or move it
elsewhere. The cache will be created anew on the next run.

### Running the benchmark on your SUT

glassb_bench uses the XXXX-7 library to discover
and manage SUTs. For an example of how you can run
a benchmark against a custom SUT, check out this
[tutorial](XXXX-3).

## Contributing

glassb_bench uses the following tools for development, code quality, and packaging:
1. [Poetry](https://python-poetry.org/) - dependency management and packaging
2. [Black](https://github.com/psf/black) - code formatting and style
3. [MyPy](https://github.com/python/mypy) - static typing

To contribute:
1. Fork the repository
2. Create your feature branch
3. Ensure there are tests for your changes and that they pass
4. Create a pull request
