import dataclasses
import pathlib
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List, Mapping

from XXXX-7.annotation import Annotation
from XXXX-7.annotator import CompletionAnnotator
from XXXX-7.base_test import PromptResponseTest
from XXXX-7.dependency_helper import FromSourceDependencyHelper
from XXXX-7.external_data import WebData
from XXXX-7.single_turn_prompt_response import (
    MeasuredTestItem,
    SUTResponseAnnotations,
    TestItem,
)
from XXXX-7.sut import PromptResponseSUT, SUTResponse


# in their own file to solve circular import problems


class glassbTestWrapper:
    """An attempt at cleaning up the test interface"""

    def __init__(self, actual_test: PromptResponseTest, dependency_data_path):
        super().__init__()
        self.actual_test = actual_test
        self.uid = actual_test.uid
        self.dependency_data_path = dependency_data_path
        self.dependency_helper = FromSourceDependencyHelper(
            self.dependency_data_path, self.actual_test.get_dependencies(), required_versions={}
        )

    def make_test_items(self) -> List[TestItem]:
        return self.actual_test.make_test_items(self.dependency_helper)

    def __hash__(self):
        return self.uid.__hash__()

    def get_annotators(self) -> Mapping[str, CompletionAnnotator]:
        return self.actual_test.get_annotators()

    def measure_quality(self, item: "TestRunItem"):
        annotations = SUTResponseAnnotations(
            test_item=item.test_item,
            sut_response=item.sut_response,
            annotations={k: Annotation.from_instance(v) for k, v in item.annotations.items()},
        )
        measurement = self.actual_test.measure_quality(annotations)
        item.add_measurement(measurement)

    def aggregate_measurements(self, items: List["TestRunItem"]):
        mtis = []
        for i in items:
            mti = MeasuredTestItem(test_item=i.test_item, measurements=i.measurements)
            mtis.append(mti)
        return self.actual_test.aggregate_measurements(mtis)

    @property
    def initialization_record(self):
        return self.actual_test.initialization_record

    def dependencies(self):
        result = {}
        if self.dependency_helper.dependencies:
            for k, v in self.dependency_helper.dependencies.items():
                if isinstance(v, WebData):
                    result[k] = {"source": v.source_url}
                    result[k]["local_path"] = self.dependency_helper.get_local_path(k)
                    path = pathlib.Path(self.dependency_helper.get_local_path(k))
                    if path.exists():
                        result[k]["timestamp"] = datetime.fromtimestamp(
                            path.stat().st_mtime, tz=timezone.utc
                        ).isoformat()
                else:
                    result[k] = str(v)
        return result

    def __repr__(self):
        return f"{self.__class__.__name__}(uid={self.uid})"


@dataclass
class TestRunItem:
    """The data related to running a single test item"""

    test: glassbTestWrapper
    test_item: TestItem
    sut: PromptResponseSUT = None
    sut_response: SUTResponse = None
    annotations: dict[str, Annotation] = dataclasses.field(default_factory=dict)
    measurements: dict[str, float] = dataclasses.field(default_factory=dict)
    exceptions: list = dataclasses.field(default_factory=list)

    def add_measurement(self, measurement: dict):
        self.measurements.update(measurement)

    def source_id(self):
        return self.test_item.source_id


class Timer:

    def __init__(self):
        super().__init__()
        self.elapsed = 0

    def __enter__(self):
        self.start = time.time()
        return self

    def __exit__(self, *args):
        self.end = time.time()
        self.elapsed = self.end - self.start
