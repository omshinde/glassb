"""
This namespace plugin loader will discover and load all plugins from XXXX-7's plugin directories.

To see this in action:

* poetry install
* poetry run XXXX-7 list
* poetry install --extras demo
* poetry run XXXX-7 list

The demo plugin modules will only print on the second run.
"""

import importlib
import pkgutil
from types import ModuleType
from typing import Iterator, List

from tqdm import tqdm

import XXXX-7
import XXXX-7.annotators
import XXXX-7.runners
import XXXX-7.suts
import XXXX-7.tests


def _iter_namespace(ns_pkg: ModuleType) -> Iterator[pkgutil.ModuleInfo]:
    return pkgutil.iter_modules(ns_pkg.__path__, ns_pkg.__name__ + ".")


def list_plugins() -> List[str]:
    """Get a list of plugin module names without attempting to import them."""
    module_names = []
    for ns in ["tests", "suts", "runners", "annotators"]:
        for _, name, _ in _iter_namespace(getattr(XXXX-7, ns)):
            module_names.append(name)
    return module_names


plugins_loaded = False


def load_plugins(disable_progress_bar: bool = False) -> None:
    """Import all plugin modules."""
    global plugins_loaded
    if not plugins_loaded:
        plugins = list_plugins()
        for module_name in tqdm(
            plugins,
            desc="Loading plugins",
            disable=disable_progress_bar or len(plugins) == 0,
        ):
            importlib.import_module(module_name)
        plugins_loaded = True
