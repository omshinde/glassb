from XXXX-7.base_test import BaseTest
from XXXX-7.instance_factory import InstanceFactory

# The list of all Test instances with assigned UIDs.
TESTS = InstanceFactory[BaseTest]()
