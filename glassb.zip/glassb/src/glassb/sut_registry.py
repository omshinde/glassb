from XXXX-7.instance_factory import InstanceFactory
from XXXX-7.sut import SUT

# The list of all SUT instances with assigned UIDs.
SUTS = InstanceFactory[SUT]()
