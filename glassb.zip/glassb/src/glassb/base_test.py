from abc import ABC, abstractmethod
from XXXX-7.dependency_helper import DependencyHelper
from XXXX-7.external_data import ExternalData
from XXXX-7.record_init import InitializationRecord
from XXXX-7.single_turn_prompt_response import (
    MeasuredTestItem,
    SUTResponseAnnotations,
    TestItem,
)
from XXXX-7.sut import SUTOptions
from XXXX-7.sut_capabilities import SUTCapability
from XXXX-7.tracked_object import TrackedObject
from XXXX-7.typed_data import Typeable, TypedData
from typing import Dict, List, Mapping, Sequence, Type


class BaseTest(TrackedObject):
    """This is the placeholder base class for all tests.

    Test classes should be decorated with `@glassb_test`, which sets the
    class attribute `requires_sut_capabilities` as well as `initialization_record` of test instances.

    Attributes:
        requires_sut_capabilities: List of capabilities a SUT must report in order to run this test.
            Test classes must specify their requirements in the `@glassb_test` decorator args.
        uid (str): Unique identifier for a test instance.
        initialization_record: Initialization data that can be used to reconstruct a test instance.
    """

    _sut_options = SUTOptions()

    # Set automatically by @glassb_test()
    requires_sut_capabilities: Sequence[Type[SUTCapability]]

    def __init__(self, uid: str):
        super().__init__(uid)
        # The initialization record is set automatically by @glassb_test()
        self.initialization_record: InitializationRecord

    def sut_options(self) -> SUTOptions:
        """Returns the SUT options that are supplied in each test item.
        Concrete subclasses can override this method to specify their own SUT options."""
        return self._sut_options


class PromptResponseTest(BaseTest, ABC):
    """Interface for all tests that are single turn.

    Concrete subclasses must implement every method in the interface.
    See `BaseTest` for more information regarding test implementation."""

    @classmethod
    @abstractmethod
    def get_annotators(cls) -> List[str]:
        """Return a list of annotators UIDs Test wants to run.

        List can be empty.
        """
        pass

    @abstractmethod
    def get_dependencies(self) -> Mapping[str, ExternalData]:
        """Return a mapping of external dependency name to how it can be found downloaded."""
        pass

    @abstractmethod
    def make_test_items(self, dependency_helper: DependencyHelper) -> List[TestItem]:
        """Generate all data that will eventually go to the SUT."""
        pass

    @abstractmethod
    def measure_quality(self, item: SUTResponseAnnotations) -> Dict[str, float]:
        """Use the SUT response with annotations to determine how well the SUT did on this TestItem."""
        pass

    @abstractmethod
    def aggregate_measurements(self, items: List[MeasuredTestItem]) -> Typeable:
        """Combine the measurements for each TestItem into a test specific Typeable."""
        pass


class TestResult(TypedData):
    """Container for plugin defined Test result data.

    Every Test can return data however it wants, so this generically
    records the Test's return type and data.
    You can use `to_instance` to get back to the original form.
    """

    # Convince pytest to ignore this class.
    __test__ = False
