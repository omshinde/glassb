from XXXX-7.instance_factory import InstanceFactory
from XXXX-7.annotator import Annotator

# The list of all Annotators instances with assigned UIDs.
ANNOTATORS = InstanceFactory[Annotator]()
