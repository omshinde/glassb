# SUT plugins

XXXX-7 uses [namespace plugins](../../docs/plugins.md) to separate the core libraries from the implementation of less central code. That way you only have to install the dependencies you actually care about.

Any file put in this directory, or in any installed package with a namespace of `XXXX-7.suts`, will be automatically loaded by the XXXX-7 command line tool via `load_plugins()`.
