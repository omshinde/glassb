from XXXX-7.prompt import ChatPrompt, TextPrompt
from XXXX-7.sut import PromptResponseSUT, SUTOptions, SUTResponse
from XXXX-7.sut_capabilities import AcceptsChatPrompt, AcceptsTextPrompt
from XXXX-7.sut_decorator importXXXX-13
from pydantic import BaseModel


class FakeSUTRequest(BaseModel):
    text: str


class FakeSUTResponse(BaseModel):
    text: str


@glassb_sut(capabilities=[AcceptsTextPrompt, AcceptsChatPrompt])
class FakeSUT(PromptResponseSUT[FakeSUTRequest, FakeSUTResponse]):
    """SUT that just echos the prompt text back."""

    def __init__(self, uid: str = "fake-sut"):
        super().__init__(uid)
        self.evaluate_calls = 0

    def translate_text_prompt(self, prompt: TextPrompt, options: SUTOptions) -> FakeSUTRequest:
        return FakeSUTRequest(text=prompt.text)

    def translate_chat_prompt(self, prompt: ChatPrompt, options: SUTOptions) -> FakeSUTRequest:
        return FakeSUTRequest(text=prompt.messages[-1].text)

    def evaluate(self, request: FakeSUTRequest) -> FakeSUTResponse:
        self.evaluate_calls += 1
        return FakeSUTResponse(text=request.text)

    def translate_response(self, request: FakeSUTRequest, response: FakeSUTResponse) -> SUTResponse:
        return SUTResponse(text=response.text)
