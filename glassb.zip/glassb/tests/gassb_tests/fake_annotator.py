from XXXX-7.annotator import CompletionAnnotator
from XXXX-7.single_turn_prompt_response import TestItem
from XXXX-7.sut import SUTResponse
from pydantic import BaseModel


class FakeAnnotation(BaseModel):
    sut_text: str


class FakeAnnotatorRequest(BaseModel):
    text: str


class FakeAnnotatorResponse(BaseModel):
    sut_text: str


class FakeAnnotator(CompletionAnnotator[FakeAnnotation]):
    """Fake annotator that just returns the first completion from the SUT."""

    def __init__(self, uid):
        super().__init__(uid)
        self.annotate_calls = 0

    def translate_request(self, test_item: TestItem, response: SUTResponse):
        return FakeAnnotatorRequest(text=response.text)

    def annotate(self, annotation_request: FakeAnnotatorRequest):
        """Returns an annotation for a single TestItem's interactions."""
        self.annotate_calls += 1
        return FakeAnnotatorResponse(sut_text=annotation_request.text)

    def translate_response(self, request, response: FakeAnnotatorResponse) -> FakeAnnotation:
        return FakeAnnotation(sut_text=response.sut_text)
