## Contributing

The best way to contribute to the XXXX-3 is to get involved with one of our many project communities. You find more information about getting involved with XXXX-3 [here](XXXX-3). 

Generally we encourage people to become a XXXX-3 member if they wish to contribute to XXXX-3 projects, but outside pull requests are very welcome too.

Regardless of if you are a member, your organization needs to sign the XXXX-3 CLA. Please fill out this [CLA sign up form](https://forms.gle/Ew1KkBVpyeJDuRw67) form to get started.

XXXX-3 project work is tracked with issue trackers and pull requests. Modify the project in your own fork and issue a pull request once you want other developers to take a look at what you have done and discuss the proposed changes. Ensure that cla-bot and other checks pass for your Pull requests.