# Demo Plugin

This directory contains worked examples for how to define your own Tests, and SUTs in XXXX-7. For a more detailed tutorial, see the docs. To see this code in action, from the top level git directory:

```
poetry install --extras demo
poetry run XXXX-7 run-test --test demo_01 --sut demo_yes_no
```
