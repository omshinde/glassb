# Demo Web Hosted Data

These files are used to simulate downloading web data in the demo plugin. They are **not** packaged with the code.